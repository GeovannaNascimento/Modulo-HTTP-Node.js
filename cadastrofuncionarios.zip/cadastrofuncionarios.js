exports.myDateTime3 = function () {
    return Date();
  };
