
exports.myDateTime2 = function () {
    return Date();
  };
